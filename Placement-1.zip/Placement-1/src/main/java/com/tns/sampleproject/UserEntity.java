package com.tns.sampleproject;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class UserEntity {

		@Id
		@Column(name="userID")
		private long userID;
		
		@Column(name="userName")
		private String userName;
		
		@Column(name="userType")
		private String userType;
		
		@Column(name="password")
		private String password;
		

		public long getUserID() {
			return userID;
		}

		public void setUserID(int userID) {
			this.userID = userID;
		}

		public String getUserName() {
			return userName;
		}

		public void setUserName(String userName) {
			this.userName = userName;
		}


		public String getUserType() {
			return userType;
		}

		public void setUserType(String userType) {
			this.userType = userType;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}

		
		public UserEntity() {
			super();
			// TODO Auto-generated constructor stub
		}

		public UserEntity(int userID, String userName,String userType, String password) {
			super();
			this.userID = userID;
			this.userName = userName;
			this.userType = userType;
			this.password = password;
		}

		@Override
		public String toString() {
			return "User [userID=" + userID + ", userName=" + userName + ", userType=" + userType + ", password=" + password+ "]";
		}

}
