package com.tns.sampleproject;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class UserService {
	
		@Autowired
		private UserEntity repo;
		
		public void save(UserEntity user)
		{
			repo.save(user);
		}
		
		public List<UserEntity> getAllUser()
		{
			return repo.findAll();
		}
		
		public UserEntity getUserById(Integer id) 
		{
			return repo.findById(id).orElse(null);
		}
		
		public void deleteUser(Integer id)
		{
			repo.deleteById(id);
		}

		public void updateUser(Integer id , UserEntity updatedUser)
		{
			UserEntity existingUser = repo.findById(id).orElse(null);
			if (existingUser != null)
			{
				existingUser.setUserName(updatedUser.getUserName());
				existingUser.setUserType(updatedUser.getUserType());
				existingUser.setPassword(updatedUser.getPassword());
				repo.save(existingUser);
			}
		}
}
