package com.tns.sampleproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Placement1Application {

	public static void main(String[] args) {
		SpringApplication.run(Placement1Application.class, args);
	}

}
